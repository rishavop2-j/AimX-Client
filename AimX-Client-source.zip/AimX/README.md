# AimX CLIENT (Fabric, Minecraft Java 1.20.1, PojavLauncher)

Lightweight utility client. 18 modules, touch-friendly menu, JSON config, no mixins
(only Fabric API events), so it is small and unlikely to conflict with other mods.

## Modules
Combat: Aim Assist (target selection, smooth tracking, speed/range/FOV/prediction), Target Tracking (HUD)
Movement: Bridge Assist, Movement Boost, Jump Enhancement, Flight Mode, Sprint Assist, Movement Profiles
Player: Survival HUD, Damage Test, Hunger Test, Invulnerability Test (the 3 tests are singleplayer only)
Visuals: Entity ESP, Player ESP, Mob ESP, Item ESP (boxes, tracer lines, distance labels, name tags, hue color)
Settings: Performance Mode, Interface (accent color, animations, menu key)
Config tab: Save / Reload / Reset / All off

## Build (pick one)
A) On your phone, no PC: push this folder to a GitHub repo -> Actions tab -> "build" runs
   automatically -> download artifact "AimX-Client" -> unzip -> aimx-client-1.0.0.jar.
B) On a PC with JDK 17 and Gradle 8.5+:  `gradle build`   (jar: build/libs/aimx-client-1.0.0.jar)
   Or generate the wrapper once with `gradle wrapper --gradle-version 8.5`, then `./gradlew build`.

## Install on PojavLauncher
1. Install PojavLauncher, create a profile for Minecraft 1.20.1, run it once.
2. Install Fabric Loader 0.15.x for 1.20.1 (use your launcher's Fabric installer, or import the
   Fabric installer .jar through Pojav's "install .jar" option). Select the Fabric 1.20.1 profile.
3. Download Fabric API 0.92.2+1.20.1 (Modrinth) and put BOTH jars (fabric-api + aimx-client) in the mods folder:
   `Android/data/net.kdt.pojavlaunch/files/.minecraft/mods` (older: `/storage/emulated/0/games/PojavLauncher/.minecraft/mods`).
   With per-instance setups: `.../instances/<name>/mods`.
4. Profile settings: Java 17 runtime, 2000-3000 MB RAM, renderer GL4ES or Zink; low render distance (6-8).
5. Launch. Open the menu: tap Pause (Esc button) -> **AimX** button top-left. Keyboard users: Right Shift.

## Use
Tap a module name to expand its settings; tap the switch to enable. Drag sliders. Drag empty space to scroll.
Keybinds: expand a module -> Keybind -> press a key. Settings live in `config/aimx.json`.

## Troubleshooting
- Game crashes on start: check Fabric Loader >= 0.14.21, Fabric API present, Java 17, MC exactly 1.20.1.
- No AimX button: make sure the jar is in the same mods folder as fabric-api; look for "AimX CLIENT loaded" in latest.log.
- ESP lines missing: some GL4ES builds ignore line width (lines still draw thin). Try the Zink renderer.
- Low FPS: enable Performance Mode, lower ESP distance/entities, turn off Tracer Lines and Animations.
- Flight kicks you: servers disallow flight; works in singleplayer. Damage/Hunger/Invulnerability tests need a singleplayer world.
- Broken config: delete `config/aimx.json` (a corrupt file is auto-moved to aimx.json.bak).
- Build error `package ... does not exist`: confirm gradle.properties versions match (1.20.1, yarn 1.20.1+build.10).

## Fair-play note
Aim Assist, Flight, Speed and ESP are cheats on most public multiplayer servers and will get you banned.
Use them in singleplayer, on your own server, or where the rules allow.
