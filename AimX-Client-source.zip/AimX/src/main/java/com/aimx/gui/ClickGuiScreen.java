package com.aimx.gui;

import com.aimx.AimXClient;
import com.aimx.core.*;
import com.aimx.modules.InterfaceModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** Mobile-friendly menu: tap to expand, tap switches, drag sliders, drag empty space to scroll. */
public class ClickGuiScreen extends Screen {
    private interface Act { void press(double mx); }
    private record Hit(int x, int y, int w, int h, Act act, boolean slider, boolean listArea) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private static final int PANEL = 0xFF181820, PANEL2 = 0xFF24242E, TEXT = 0xFFEDEDF7, DIM = 0xFF8A8AA0, KNOB = 0xFFFFFFFF;
    private static final String[] TABS = {"Combat", "Movement", "Player", "Visuals", "Settings", "Config"};
    private static int tab = 0;
    private static final Set<Module> OPEN = new HashSet<>();

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Object, Float> anim = new HashMap<>();
    private TextFieldWidget search;
    private Module binding;
    private Hit pressed, dragging;
    private double pressX, pressY;
    private boolean moved;
    private float scroll, scrollTarget, totalH, fade, dt;
    private int listTop, listBottom, x0, cw, sbX, sbY, sbW;
    private long last = System.nanoTime();
    private String status = "";

    public ClickGuiScreen() { super(Text.literal("AimX")); }

    @Override protected void init() {
        search = new TextFieldWidget(textRenderer, 0, 0, 100, 14, Text.literal("Search"));
        search.setDrawsBackground(false);
        search.setMaxLength(24);
        search.setChangedListener(s -> scrollTarget = 0);
    }

    private InterfaceModule ui() { return AimXClient.modules.get(InterfaceModule.class); }
    private boolean animOn() { return ui() == null || ui().animations.on(); }
    private int accent() { return 0xFF000000 | MathHelper.hsvToRgb((float) (ui().hue.num() / 360.0), 0.62f, 1f); }

    private float ease(Object k, float target) {
        float v = anim.getOrDefault(k, target);
        v = animOn() ? v + (target - v) * Math.min(1f, dt * 16f) : target;
        if (Math.abs(target - v) < 0.002f) v = target;
        anim.put(k, v);
        return v;
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        fade = animOn() ? Math.min(1f, fade + dt * 6f) : 1f;
        hits.clear();
        int acc = accent();
        c.fill(0, 0, width, height, ((int) (0xCC * fade) << 24) | 0x08080C);

        int pad = Math.max(6, width / 40);
        cw = Math.min(width - pad * 2, 480);
        x0 = (width - cw) / 2;
        int y = pad;

        // title bar + search
        RenderUtil.rrect(c, x0, y, cw, 22, 6, PANEL);
        c.drawText(textRenderer, "Aim", x0 + 9, y + 7, TEXT, false);
        c.drawText(textRenderer, "X", x0 + 9 + textRenderer.getWidth("Aim"), y + 7, acc, false);
        sbX = x0 + 56; sbW = cw - 62; sbY = y + 3;
        RenderUtil.rrect(c, sbX, sbY, sbW, 16, 6, PANEL2);
        search.setX(sbX + 7); search.setY(sbY + 4); search.setWidth(sbW - 14);
        search.render(c, mx, my, delta);
        if (search.getText().isEmpty() && !search.isFocused()) c.drawText(textRenderer, "Search modules...", sbX + 7, sbY + 4, DIM, false);

        // tabs
        y += 26;
        int tw = cw / TABS.length;
        boolean searching = !search.getText().trim().isEmpty();
        for (int i = 0; i < TABS.length; i++) {
            int tx = x0 + i * tw;
            float sel = ease("tab" + i, (tab == i && !searching) ? 1f : 0f);
            RenderUtil.rrect(c, tx + 1, y, tw - 2, 18, 5, RenderUtil.mix(PANEL, acc & 0x00FFFFFF | 0xFF000000, sel * 0.85f));
            String t = TABS[i];
            c.drawText(textRenderer, t, tx + (tw - textRenderer.getWidth(t)) / 2, y + 5, RenderUtil.mix(DIM, 0xFF101014, sel), false);
            final int k = i;
            hits.add(new Hit(tx, y, tw, 18, m -> { tab = k; scrollTarget = 0; }, false, false));
        }

        listTop = y + 23; listBottom = height - pad;
        float maxS = Math.max(0, totalH - (listBottom - listTop));
        scrollTarget = MathHelper.clamp(scrollTarget, 0, maxS);
        scroll = animOn() ? scroll + (scrollTarget - scroll) * Math.min(1f, dt * 18f) : scrollTarget;

        c.enableScissor(x0 - 2, listTop, x0 + cw + 2, listBottom);
        int cy = listTop - Math.round(scroll), startY = cy;
        String q = search.getText().trim().toLowerCase(Locale.ROOT);
        if (tab == 5 && q.isEmpty()) {
            cy = drawConfig(c, cy);
        } else {
            for (Module m : AimXClient.modules.all) {
                boolean show = q.isEmpty() ? m.category.ordinal() == tab
                        : (m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q));
                if (show) cy = drawModule(c, m, cy, acc);
            }
        }
        totalH = cy - startY + 4;
        c.disableScissor();
    }

    private int rowsHeight(Module m) {
        int h = 22; // keybind row
        for (Setting s : m.settings) h += (s.type == Setting.Type.NUM || s.type == Setting.Type.HUE) ? 32 : 22;
        return h;
    }

    private int drawModule(DrawContext c, Module m, int y, int acc) {
        boolean open = OPEN.contains(m);
        int rows = rowsHeight(m);
        float ex = ease("o" + m.name, open ? 1f : 0f);
        int exH = Math.round(rows * ex);
        int h = 26 + exH + (exH > 0 ? 4 : 0);
        if (y + h >= listTop && y <= listBottom) {
            RenderUtil.rrect(c, x0, y, cw, h, 6, PANEL);
            boolean on = m.isEnabled();
            float t = ease(m, on ? 1f : 0f);
            if (t > 0.02f) RenderUtil.rrect(c, x0 + 2, y + 6, 3, 14, 1, (acc & 0x00FFFFFF) | ((int) (255 * t) << 24));
            c.drawText(textRenderer, m.name, x0 + 11, y + 5, RenderUtil.mix(0xFFC8C8D8, TEXT, t), false);
            c.drawText(textRenderer, textRenderer.trimToWidth(m.description, cw - 96), x0 + 11, y + 15, DIM, false);
            c.drawText(textRenderer, open ? "-" : "+", x0 + cw - 58, y + 9, DIM, false);
            if (m.isMomentary()) {
                RenderUtil.rrect(c, x0 + cw - 44, y + 6, 36, 14, 6, acc);
                c.drawText(textRenderer, "RUN", x0 + cw - 44 + (36 - textRenderer.getWidth("RUN")) / 2, y + 10, 0xFF101014, false);
            } else {
                drawSwitch(c, x0 + cw - 38, y + 7, t, acc);
            }
            hits.add(new Hit(x0, y, cw - 66, 26, p -> { if (!OPEN.remove(m)) OPEN.add(m); }, false, true));
            hits.add(new Hit(x0 + cw - 66, y, 66, 26, p -> m.toggle(), false, true));

            if (ex > 0.02f) {
                c.enableScissor(x0, y + 26, x0 + cw, y + h);
                boolean live = ex > 0.95f;
                int ry = y + 28;
                for (Setting s : m.settings) ry = drawSetting(c, s, ry, acc, live);
                drawKeyRow(c, m, ry, live);
                c.disableScissor();
            }
        }
        return y + h + 4;
    }

    private void drawSwitch(DrawContext c, int x, int y, float t, int acc) {
        RenderUtil.rrect(c, x, y, 28, 12, 6, RenderUtil.mix(0xFF3A3A48, acc, t));
        RenderUtil.rrect(c, x + 2 + Math.round(16 * t), y + 2, 8, 8, 4, KNOB);
    }

    private int drawSetting(DrawContext c, Setting s, int ry, int acc, boolean live) {
        int rx = x0 + 11, rw = cw - 22;
        switch (s.type) {
            case BOOL -> {
                c.drawText(textRenderer, s.name, rx, ry + 7, 0xFFD0D0E0, false);
                drawSwitch(c, rx + rw - 28, ry + 5, ease(s, s.on() ? 1f : 0f), acc);
                if (live) hits.add(new Hit(rx, ry, rw, 22, p -> s.cycle(), false, true));
                return ry + 22;
            }
            case ENUM -> {
                c.drawText(textRenderer, s.name, rx, ry + 7, 0xFFD0D0E0, false);
                int bw = textRenderer.getWidth(s.option()) + 14;
                RenderUtil.rrect(c, rx + rw - bw, ry + 3, bw, 16, 6, PANEL2);
                c.drawText(textRenderer, s.option(), rx + rw - bw + 7, ry + 7, acc, false);
                if (live) hits.add(new Hit(rx, ry, rw, 22, p -> s.cycle(), false, true));
                return ry + 22;
            }
            default -> {
                c.drawText(textRenderer, s.name, rx, ry + 3, 0xFFD0D0E0, false);
                String v = s.type == Setting.Type.HUE ? "" : s.display();
                c.drawText(textRenderer, v, rx + rw - textRenderer.getWidth(v), ry + 3, acc, false);
                int ty = ry + 17;
                float frac = (float) ((s.value - s.min) / (s.max - s.min));
                if (s.type == Setting.Type.HUE) {
                    for (int i = 0; i < rw; i += 2) c.fill(rx + i, ty, rx + Math.min(rw, i + 2), ty + 6, 0xFF000000 | MathHelper.hsvToRgb(i / (float) rw, 0.7f, 1f));
                } else {
                    RenderUtil.rrect(c, rx, ty, rw, 6, 3, PANEL2);
                    RenderUtil.rrect(c, rx, ty, Math.max(6, (int) (rw * frac)), 6, 3, acc);
                }
                int kx = rx + (int) (rw * frac) - 4;
                RenderUtil.rrect(c, kx, ty - 2, 8, 10, 4, KNOB);
                if (live) hits.add(new Hit(rx - 4, ty - 6, rw + 8, 18, mx -> s.set(s.min + MathHelper.clamp((mx - rx) / (double) rw, 0, 1) * (s.max - s.min)), true, true));
                return ry + 32;
            }
        }
    }

    private void drawKeyRow(DrawContext c, Module m, int ry, boolean live) {
        int rx = x0 + 11, rw = cw - 22;
        c.drawText(textRenderer, "Keybind", rx, ry + 7, 0xFFD0D0E0, false);
        String label = binding == m ? "Press a key... (Esc = clear)"
                : m.key < 0 ? "None" : InputUtil.fromKeyCode(m.key, -1).getLocalizedText().getString();
        int bw = textRenderer.getWidth(label) + 14;
        RenderUtil.rrect(c, rx + rw - bw, ry + 3, bw, 16, 6, PANEL2);
        c.drawText(textRenderer, label, rx + rw - bw + 7, ry + 7, binding == m ? 0xFFFFD166 : DIM, false);
        if (live) hits.add(new Hit(rx, ry, rw, 22, p -> binding = (binding == m ? null : m), false, true));
    }

    private int drawConfig(DrawContext c, int y) {
        String[] labels = {"Save configuration", "Reload from file", "Reset all settings", "Turn all modules off"};
        Runnable[] acts = {
                () -> status = ConfigManager.save(AimXClient.modules) ? "Saved to config/aimx.json" : "Save failed (see log)",
                () -> status = ConfigManager.load(AimXClient.modules) ? "Loaded config/aimx.json" : "No valid config file found",
                () -> { AimXClient.modules.resetAll(); status = "All settings reset to defaults"; },
                () -> { AimXClient.modules.disableAll(); status = "All modules turned off"; }
        };
        for (int i = 0; i < labels.length; i++) {
            RenderUtil.rrect(c, x0, y, cw, 28, 6, PANEL);
            c.drawText(textRenderer, labels[i], x0 + 11, y + 10, TEXT, false);
            c.drawText(textRenderer, ">", x0 + cw - 16, y + 10, accent(), false);
            final int k = i;
            hits.add(new Hit(x0, y, cw, 28, p -> acts[k].run(), false, true));
            y += 32;
        }
        if (!status.isEmpty()) c.drawText(textRenderer, status, x0 + 4, y + 2, accent(), false);
        c.drawText(textRenderer, "Settings auto-save when this menu closes.", x0 + 4, y + 14, DIM, false);
        c.drawText(textRenderer, "File: .minecraft/config/aimx.json", x0 + 4, y + 26, DIM, false);
        return y + 40;
    }

    // ---------- input: actions fire on release so finger-drag scrolling never toggles things ----------
    @Override public boolean mouseClicked(double mx, double my, int b) {
        search.setFocused(mx >= sbX && mx <= sbX + sbW && my >= sbY && my <= sbY + 16);
        pressed = null; dragging = null; moved = false; pressX = mx; pressY = my;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.in(mx, my) && (!h.listArea() || (my >= listTop && my <= listBottom))) { pressed = h; break; }
        }
        if (pressed != null && pressed.slider()) { dragging = pressed; pressed.act().press(mx); }
        return true;
    }

    @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (dragging != null) { dragging.act().press(mx); return true; }
        if (Math.abs(my - pressY) > 5 || Math.abs(mx - pressX) > 5) moved = true;
        if (moved) { scrollTarget -= (float) dy; scroll = scrollTarget; }
        return true;
    }

    @Override public boolean mouseReleased(double mx, double my, int b) {
        if (!moved && pressed != null && !pressed.slider()) pressed.act().press(mx);
        pressed = null; dragging = null;
        return true;
    }

    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        scrollTarget -= (float) (amount * 28);
        return true;
    }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            binding = null;
            return true;
        }
        if (search.isFocused()) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { search.setFocused(false); return true; }
            return search.keyPressed(key, scan, mods);
        }
        InterfaceModule i = ui();
        if (key == GLFW.GLFW_KEY_ESCAPE || (i != null && key == i.key)) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override public boolean charTyped(char chr, int mods) {
        return search.isFocused() && search.charTyped(chr, mods);
    }

    @Override public void removed() { ConfigManager.save(AimXClient.modules); }
}
