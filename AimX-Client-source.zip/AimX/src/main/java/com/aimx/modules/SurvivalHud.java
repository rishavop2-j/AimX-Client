package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import java.util.*;

public class SurvivalHud extends Module {
    private final Setting health = add(Setting.bool("Health", true));
    private final Setting hunger = add(Setting.bool("Hunger", true));
    private final Setting armor = add(Setting.bool("Armor", true));
    private final Setting coords = add(Setting.bool("Coordinates", true));
    private final Setting dir = add(Setting.bool("Direction", true));
    private final Setting fps = add(Setting.bool("FPS", true));
    private final Setting hue = add(Setting.hue("Accent", 265));

    public SurvivalHud() { super("Survival HUD", "Health, hunger, coordinates and FPS overlay", Category.PLAYER); defEnabled = false; }

    @Override public void onHud(DrawContext c, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        List<String> l = new ArrayList<>();
        if (health.on()) l.add(String.format(Locale.ROOT, "HP  %.1f / %.0f", p.getHealth(), p.getMaxHealth()));
        if (hunger.on()) l.add(String.format(Locale.ROOT, "Food  %d  (sat %.1f)", p.getHungerManager().getFoodLevel(), p.getHungerManager().getSaturationLevel()));
        if (armor.on()) l.add("Armor  " + p.getArmor());
        if (coords.on()) l.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ()));
        if (dir.on()) l.add("Facing  " + p.getHorizontalFacing().asString());
        if (fps.on()) l.add("FPS  " + mc.getCurrentFps());
        if (l.isEmpty()) return;
        int w = 0;
        for (String s : l) w = Math.max(w, mc.textRenderer.getWidth(s));
        int x = 6, y = 6, h = l.size() * 11 + 6;
        RenderUtil.rrect(c, x, y, w + 16, h, 5, 0xB0121218);
        RenderUtil.rrect(c, x, y + 3, 2, h - 6, 1, 0xFF000000 | hue.rgb());
        for (int i = 0; i < l.size(); i++) c.drawText(mc.textRenderer, l.get(i), x + 8, y + 5 + i * 11, 0xFFE8E8F2, false);
    }
}
