package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;

/** Creative-style flight. Works in singleplayer; most multiplayer servers will kick for it. */
public class Flight extends Module {
    private final Setting speed = add(Setting.num("Fly Speed", 2, 0.5, 10, 0.5));
    private final Setting auto = add(Setting.bool("Auto Fly", true));
    public Flight() { super("Flight Mode", "Creative-style flying (singleplayer)", Category.MOVEMENT); }

    @Override public void onTick(ClientPlayerEntity p) {
        PlayerAbilities a = p.getAbilities();
        a.allowFlying = true;
        a.setFlySpeed(0.05f * (float) MovementProfiles.fly(speed.num()));
        if (auto.on() && !a.flying) a.flying = true;
    }

    @Override public void onDisable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        PlayerAbilities a = p.getAbilities();
        a.allowFlying = p.isCreative() || p.isSpectator();
        if (!a.allowFlying) a.flying = false;
        a.setFlySpeed(0.05f);
    }
}
