package com.aimx.modules;

import com.aimx.core.*;
import com.aimx.core.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class Sprint extends Module {
    private final Setting ignoreHunger = add(Setting.bool("Ignore Hunger Check", false));
    public Sprint() { super("Sprint Assist", "Automatically sprints while moving forward", Category.MOVEMENT); }

    @Override public void onTick(ClientPlayerEntity p) {
        if (p.input.movementForward > 0 && !p.isSneaking() && !p.horizontalCollision && !p.isUsingItem()
                && (ignoreHunger.on() || p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying)) {
            p.setSprinting(true);
        }
    }
}
