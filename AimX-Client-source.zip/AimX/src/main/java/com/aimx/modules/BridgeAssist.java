package com.aimx.modules;

import com.aimx.core.*;
import com.aimx.core.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.Box;

/** Auto-sneak at block edges so you never walk off while bridging. */
public class BridgeAssist extends Module {
    private final Setting margin = add(Setting.num("Edge Margin", 0.4, 0.1, 0.8, 0.05));
    private final Setting blocksOnly = add(Setting.bool("Only With Blocks", true));
    private boolean forced;

    public BridgeAssist() { super("Bridge Assist", "Auto-sneaks at block edges", Category.MOVEMENT); }

    @Override public void onPreTick(ClientPlayerEntity p) {
        if (edge(p)) { mc.options.sneakKey.setPressed(true); forced = true; }
        else if (forced) release();
    }

    private void release() { forced = false; KeyBinding.updatePressedStates(); }
    @Override public void onDisable() { if (forced) release(); }

    private boolean edge(ClientPlayerEntity p) {
        if (!p.isOnGround() || p.getAbilities().flying || p.isTouchingWater()) return false;
        if (blocksOnly.on() && !(p.getMainHandStack().getItem() instanceof BlockItem)
                && !(p.getOffHandStack().getItem() instanceof BlockItem)) return false;
        float f = p.input.movementForward, s = p.input.movementSideways;
        if (f == 0 && s == 0) return false;
        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s, dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.hypot(dx, dz);
        if (len < 1e-4) return false;
        Box probe = p.getBoundingBox().offset(dx / len * margin.num(), -0.65, dz / len * margin.num());
        return mc.world.isSpaceEmpty(p, probe);
    }
}
