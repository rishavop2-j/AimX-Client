package com.aimx.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

/** Entity highlighting for passive creatures (animals, villagers, etc.). */
public class EntityEsp extends EspModule {
    public EntityEsp() { super("Entity ESP", "Highlights animals and other living entities", 190); }
    @Override protected boolean accepts(Entity e) {
        return e instanceof LivingEntity && !(e instanceof PlayerEntity) && !(e instanceof Monster) && !(e instanceof ArmorStandEntity);
    }
}
