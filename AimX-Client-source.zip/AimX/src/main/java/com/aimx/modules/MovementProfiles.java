package com.aimx.modules;

import com.aimx.AimXClient;
import com.aimx.core.*;

/** When ON, overrides Speed / Jump / Flight values with a preset or your own custom profile. */
public class MovementProfiles extends Module {
    private final Setting profile = add(Setting.mode("Profile", 1, "Legit", "Normal", "Fast", "Custom"));
    private final Setting cSpeed = add(Setting.num("Custom Speed", 1.5, 1, 4, 0.1));
    private final Setting cJump = add(Setting.num("Custom Jump", 1.4, 1, 3, 0.1));
    private final Setting cFly = add(Setting.num("Custom Fly Speed", 2, 0.5, 10, 0.5));
    private static final double[][] PRESETS = {{1.15, 1.1, 1.0}, {1.5, 1.5, 2.0}, {2.5, 2.2, 4.0}};

    public MovementProfiles() { super("Movement Profiles", "Preset or custom values for speed, jump and flight", Category.MOVEMENT); }

    private double pick(int i, Setting custom) { return profile.idx() == 3 ? custom.num() : PRESETS[profile.idx()][i]; }

    private static MovementProfiles active() {
        MovementProfiles p = AimXClient.modules.get(MovementProfiles.class);
        return p != null && p.isEnabled() ? p : null;
    }
    public static double speed(double own) { MovementProfiles p = active(); return p == null ? own : p.pick(0, p.cSpeed); }
    public static double jump(double own) { MovementProfiles p = active(); return p == null ? own : p.pick(1, p.cJump); }
    public static double fly(double own) { MovementProfiles p = active(); return p == null ? own : p.pick(2, p.cFly); }
}
