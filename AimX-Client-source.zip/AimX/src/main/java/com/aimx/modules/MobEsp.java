package com.aimx.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;

public class MobEsp extends EspModule {
    public MobEsp() { super("Mob ESP", "Highlights hostile mobs", 0); }
    @Override protected boolean accepts(Entity e) { return e instanceof Monster && e instanceof LivingEntity; }
}
