package com.aimx.modules;

import com.aimx.core.*;
import com.aimx.core.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import java.util.Locale;

/** HUD card showing the currently selected target (name, distance, health). */
public class TargetTracking extends Module {
    private final Setting range = add(Setting.num("Range", 20, 4, 64, 2));
    private final Setting mode = add(Setting.mode("Target Selection", 0, Targets.MODES));
    private final Setting players = add(Setting.bool("Players", true));
    private final Setting hostile = add(Setting.bool("Hostile Mobs", true));
    private final Setting passive = add(Setting.bool("Passive Mobs", false));
    private LivingEntity target;

    public TargetTracking() { super("Target Tracking", "Shows the nearest target's name, distance and health", Category.COMBAT); }

    @Override public void onDisable() { target = null; }

    @Override public void onTick(ClientPlayerEntity p) {
        if (p.age % 4 != 0) return;
        target = Targets.find(mc, range.num(), 360, mode.idx(), players.on(), hostile.on(), passive.on(), true);
    }

    @Override public void onHud(DrawContext c, float td) {
        LivingEntity t = target;
        if (t == null || !t.isAlive() || mc.player == null) return;
        int w = 110, h = 30, x = mc.getWindow().getScaledWidth() / 2 + 14, y = mc.getWindow().getScaledHeight() / 2 + 14;
        RenderUtil.rrect(c, x, y, w, h, 5, 0xC0121218);
        c.drawText(mc.textRenderer, mc.textRenderer.trimToWidth(t.getName().getString(), w - 10), x + 6, y + 5, 0xFFFFFFFF, false);
        c.drawText(mc.textRenderer, String.format(Locale.ROOT, "%.1fm", mc.player.distanceTo(t)), x + 6, y + 15, 0xFF9A9AB0, false);
        float frac = Math.max(0f, Math.min(1f, t.getHealth() / Math.max(1f, t.getMaxHealth())));
        RenderUtil.rrect(c, x + 6, y + 25, w - 12, 3, 1, 0xFF2A2A34);
        RenderUtil.rrect(c, x + 6, y + 25, Math.max(2, (int) ((w - 12) * frac)), 3, 1, RenderUtil.mix(0xFFFF4466, 0xFF55E08A, frac));
    }
}
