package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class HighJump extends Module {
    private final Setting mult = add(Setting.num("Jump Multiplier", 1.5, 1, 3, 0.1));
    private boolean wasOnGround;
    public HighJump() { super("Jump Enhancement", "Boosts jump velocity", Category.MOVEMENT); }

    @Override public void onTick(ClientPlayerEntity p) {
        boolean g = p.isOnGround();
        Vec3d v = p.getVelocity();
        if (wasOnGround && !g && v.y > 0.1 && p.input.jumping) {
            p.setVelocity(v.x, v.y * MovementProfiles.jump(mult.num()), v.z);
        }
        wasOnGround = g;
    }
}
