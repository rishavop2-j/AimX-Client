package com.aimx.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class PlayerEsp extends EspModule {
    public PlayerEsp() { super("Player ESP", "Highlights other players", 285); }
    @Override protected boolean accepts(Entity e) { return e instanceof PlayerEntity && !e.isSpectator(); }
}
