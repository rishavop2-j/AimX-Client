package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Target tracking + smooth aim assistance. Target picked at 20 Hz, rotation applied every frame. */
public class AimAssist extends Module {
    private final Setting range = add(Setting.num("Range", 4.5, 1, 12, 0.5));
    private final Setting fov = add(Setting.num("FOV", 90, 10, 360, 5));
    private final Setting speed = add(Setting.num("Aim Speed", 6, 1, 20, 1));
    private final Setting maxTurn = add(Setting.num("Max Turn (deg/s)", 300, 60, 1000, 20));
    private final Setting predict = add(Setting.num("Prediction (ticks)", 0, 0, 5, 0.5));
    private final Setting mode = add(Setting.mode("Target Selection", 0, Targets.MODES));
    private final Setting point = add(Setting.mode("Aim Point", 1, "Head", "Chest", "Feet"));
    private final Setting players = add(Setting.bool("Players", true));
    private final Setting hostile = add(Setting.bool("Hostile Mobs", true));
    private final Setting passive = add(Setting.bool("Passive Mobs", false));
    private final Setting walls = add(Setting.bool("Through Walls", false));
    private final Setting attackOnly = add(Setting.bool("Only While Attacking", true));
    private LivingEntity target;

    public AimAssist() { super("Aim Assist", "Smoothly tracks the selected target", Category.COMBAT); }

    @Override public void onDisable() { target = null; }

    @Override public void onTick(ClientPlayerEntity p) {
        if (mc.currentScreen != null || (attackOnly.on() && !mc.options.attackKey.isPressed())) { target = null; return; }
        target = Targets.find(mc, range.num(), fov.num(), mode.idx(), players.on(), hostile.on(), passive.on(), walls.on());
    }

    @Override public void onFrame(ClientPlayerEntity p, float dt) {
        LivingEntity t = target;
        if (t == null || !t.isAlive() || mc.currentScreen != null) return;
        float td = mc.getTickDelta();
        double h = switch (point.idx()) { case 0 -> 0.92; case 1 -> 0.65; default -> 0.12; };
        Vec3d vel = new Vec3d(t.getX() - t.prevX, t.getY() - t.prevY, t.getZ() - t.prevZ);
        Vec3d aim = t.getLerpedPos(td).add(0, t.getHeight() * h, 0).add(vel.multiply(predict.num()));
        float[] r = Targets.rotationTo(p.getCameraPosVec(td), aim);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        float f = (float) (1.0 - Math.exp(-speed.num() * dt));
        float cap = maxTurn.f() * dt;
        float sy = MathHelper.clamp(dyaw * f, -cap, cap);
        float sp = MathHelper.clamp(dpitch * f, -cap, cap);
        // changeLookDirection keeps prevYaw/prevPitch in sync so rendering stays smooth.
        p.changeLookDirection(sy / 0.15, sp / 0.15);
    }
}
