package com.aimx.modules;

import com.aimx.core.*;
import com.aimx.gui.ClickGuiScreen;
import org.lwjgl.glfw.GLFW;

/** Opens the menu. Its keybind is the menu key (default Right Shift). Also themes the UI. */
public class InterfaceModule extends Module {
    public final Setting hue = add(Setting.hue("Accent Color", 265));
    public final Setting animations = add(Setting.bool("Animations", true));

    public InterfaceModule() {
        super("Interface", "Menu theme and menu key (also: Pause menu > AimX)", Category.SETTINGS);
        momentary = true;
        defaultKey(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override public void onEnable() { mc.setScreen(new ClickGuiScreen()); }
}
