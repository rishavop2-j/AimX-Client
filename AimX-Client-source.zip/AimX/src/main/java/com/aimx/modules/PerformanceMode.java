package com.aimx.modules;

import com.aimx.AimXClient;
import com.aimx.core.*;

/** When ON, ESP is capped to the distance and entity count below. Recommended on phones. */
public class PerformanceMode extends Module {
    private final Setting dist = add(Setting.num("ESP Distance Cap", 40, 16, 128, 4));
    private final Setting entities = add(Setting.num("Max ESP Entities", 25, 5, 200, 5));

    public PerformanceMode() { super("Performance Mode", "Caps ESP range and entity count for stable FPS", Category.SETTINGS); defEnabled = true; }

    private static PerformanceMode get() {
        PerformanceMode p = AimXClient.modules.get(PerformanceMode.class);
        return p != null && p.isEnabled() ? p : null;
    }
    public static double maxRange() { PerformanceMode p = get(); return p == null ? 256 : p.dist.num(); }
    public static int maxEntities() { PerformanceMode p = get(); return p == null ? 500 : (int) p.entities.num(); }
}
