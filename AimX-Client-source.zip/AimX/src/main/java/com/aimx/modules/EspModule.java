package com.aimx.modules;

import com.aimx.core.*;
import com.aimx.core.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.*;

/** Shared ESP renderer: boxes, tracers, distance labels, name tags, custom colour. */
public abstract class EspModule extends Module {
    protected final Setting range, box, tracers, distance, tags, hue, width;

    protected EspModule(String name, String desc, double defaultHue) {
        super(name, desc, Category.VISUALS);
        range = add(Setting.num("Render Distance", 64, 8, 128, 4));
        box = add(Setting.bool("Boxes", true));
        tracers = add(Setting.bool("Tracer Lines", false));
        distance = add(Setting.bool("Distance Labels", true));
        tags = add(Setting.mode("Name Tags", 1, "Off", "Name", "Name + Health"));
        hue = add(Setting.hue("Color", defaultHue));
        width = add(Setting.num("Line Width", 2, 1, 5, 1));
    }

    protected abstract boolean accepts(Entity e);

    @Override public void onRender3d(WorldRenderContext ctx) {
        if (mc.world == null || mc.player == null) return;
        Camera cam = ctx.camera();
        Vec3d cp = cam.getPos();
        float td = ctx.tickDelta();
        double max = Math.min(range.num(), PerformanceMode.maxRange()), max2 = max * max;
        List<Entity> list = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !accepts(e) || e.squaredDistanceTo(cp) > max2) continue;
            list.add(e);
        }
        if (list.isEmpty()) return;
        int cap = PerformanceMode.maxEntities();
        if (list.size() > cap) {
            list.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(cp)));
            list = new ArrayList<>(list.subList(0, cap));
        }
        int rgb = hue.rgb();
        MatrixStack ms = ctx.matrixStack();

        if (box.on() || tracers.on()) {
            RenderUtil.begin(ms.peek().getPositionMatrix(), width.f());
            Vec3d start = Vec3d.fromPolar(cam.getPitch(), cam.getYaw()).multiply(0.4);
            for (Entity e : list) {
                Vec3d p = e.getLerpedPos(td).subtract(cp);
                double hw = e.getWidth() / 2.0, h = e.getHeight();
                if (box.on()) RenderUtil.box(new Box(p.x - hw, p.y, p.z - hw, p.x + hw, p.y + h, p.z + hw), rgb, 1f);
                if (tracers.on()) RenderUtil.line(start.x, start.y, start.z, p.x, p.y + h / 2, p.z, rgb, 0.9f);
            }
            RenderUtil.end();
        }

        if (distance.on() || tags.idx() > 0) {
            for (Entity e : list) {
                Vec3d p = e.getLerpedPos(td).subtract(cp);
                double dist = Math.sqrt(e.squaredDistanceTo(cp));
                StringBuilder sb = new StringBuilder();
                if (tags.idx() > 0) {
                    sb.append(e.getName().getString());
                    if (e instanceof ItemEntity ie && ie.getStack().getCount() > 1) sb.append(" x").append(ie.getStack().getCount());
                    if (tags.idx() == 2 && e instanceof LivingEntity le) sb.append(" \u00a7c").append(Math.round(le.getHealth())).append("HP");
                }
                if (distance.on()) {
                    if (sb.length() > 0) sb.append(" \u00a77");
                    sb.append(String.format(Locale.ROOT, "%.1fm", dist));
                }
                float scale = 0.025f * (float) Math.max(1.0, dist / 10.0);
                RenderUtil.label(ms, cam, p.x, p.y + e.getHeight() + 0.4, p.z, sb.toString(), scale);
            }
        }
    }
}
