package com.aimx.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;

public class ItemEsp extends EspModule {
    public ItemEsp() { super("Item ESP", "Highlights dropped items", 50); }
    @Override protected boolean accepts(Entity e) { return e instanceof ItemEntity; }
}
