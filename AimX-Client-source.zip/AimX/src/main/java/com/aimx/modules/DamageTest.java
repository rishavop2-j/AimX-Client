package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.entity.damage.*;
import net.minecraft.server.network.ServerPlayerEntity;

/** One-shot test: damages yourself. Singleplayer only (runs on the integrated server). */
public class DamageTest extends Module {
    private final Setting amount = add(Setting.num("Damage", 4, 1, 20, 1));
    private final Setting type = add(Setting.mode("Type", 0, "Generic", "Fall", "Fire", "Magic", "Starve", "Drown"));

    public DamageTest() { super("Damage Test", "Hurt yourself to test armor and health HUD", Category.PLAYER); momentary = true; }

    @Override public void onEnable() {
        ServerPlayerEntity sp = serverPlayer();
        if (sp == null) { info("Damage Test works in singleplayer worlds only"); return; }
        float amt = amount.f(); int t = type.idx();
        mc.getServer().execute(() -> {
            DamageSources ds = sp.getDamageSources();
            DamageSource src = switch (t) { case 1 -> ds.fall(); case 2 -> ds.onFire(); case 3 -> ds.magic(); case 4 -> ds.starve(); case 5 -> ds.drown(); default -> ds.generic(); };
            sp.damage(src, amt);
        });
    }
}
