package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.server.network.ServerPlayerEntity;

/** One-shot test: sets your hunger. Singleplayer only. */
public class HungerTest extends Module {
    private final Setting level = add(Setting.num("Food Level", 6, 0, 20, 1));
    private final Setting sat = add(Setting.num("Saturation", 0, 0, 20, 1));

    public HungerTest() { super("Hunger Test", "Set food level and saturation to test hunger effects", Category.PLAYER); momentary = true; }

    @Override public void onEnable() {
        ServerPlayerEntity sp = serverPlayer();
        if (sp == null) { info("Hunger Test works in singleplayer worlds only"); return; }
        int lv = (int) level.num(); float st = sat.f();
        mc.getServer().execute(() -> { sp.getHungerManager().setFoodLevel(lv); sp.getHungerManager().setSaturationLevel(st); });
    }
}
