package com.aimx.modules;

import com.aimx.core.*;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.*;
import java.util.UUID;

/** Movement boost via a movement-speed attribute modifier (vanilla-accurate, no velocity hacks). */
public class Speed extends Module {
    private static final UUID ID = UUID.fromString("a1b2c3d4-0000-4000-8000-00000000a1b2");
    private final Setting mult = add(Setting.num("Speed Multiplier", 1.5, 1, 4, 0.1));
    private double applied = -1;

    public Speed() { super("Movement Boost", "Increases ground movement speed", Category.MOVEMENT); }

    @Override public void onTick(ClientPlayerEntity p) {
        EntityAttributeInstance a = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (a == null) return;
        double m = MovementProfiles.speed(mult.num());
        if (a.getModifier(ID) != null && Math.abs(m - applied) < 1e-6) return;
        a.removeModifier(ID);
        if (m > 1.0001) a.addTemporaryModifier(new EntityAttributeModifier(ID, "AimX boost", m - 1.0, EntityAttributeModifier.Operation.MULTIPLY_TOTAL));
        applied = m;
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (a != null) a.removeModifier(ID);
        applied = -1;
    }
}
