package com.aimx;

import com.aimx.core.*;
import com.aimx.gui.ClickGuiScreen;
import com.aimx.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AimXClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("AimX");
    public static ModuleManager modules;

    @Override public void onInitializeClient() {
        modules = new ModuleManager();
        // Combat
        modules.register(new AimAssist());
        modules.register(new TargetTracking());
        // Movement
        modules.register(new BridgeAssist());
        modules.register(new Speed());
        modules.register(new HighJump());
        modules.register(new Flight());
        modules.register(new Sprint());
        modules.register(new MovementProfiles());
        // Player
        modules.register(new SurvivalHud());
        modules.register(new DamageTest());
        modules.register(new HungerTest());
        modules.register(new InvulnerabilityTest());
        // Visuals
        modules.register(new EntityEsp());
        modules.register(new PlayerEsp());
        modules.register(new MobEsp());
        modules.register(new ItemEsp());
        // Settings
        modules.register(new PerformanceMode());
        modules.register(new InterfaceModule());

        for (Module m : modules.all) if (m.defEnabled) m.setEnabled(true);
        ConfigManager.load(modules);

        ClientTickEvents.START_CLIENT_TICK.register(c -> modules.preTick());
        ClientTickEvents.END_CLIENT_TICK.register(c -> { modules.pollKeys(); modules.tick(); });
        WorldRenderEvents.START.register(ctx -> modules.frame());
        WorldRenderEvents.LAST.register(modules::render3d);
        HudRenderCallback.EVENT.register(modules::hud);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.save(modules));

        // Touch-friendly entry point: an "AimX" button on the pause menu.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("AimX"),
                        b -> client.setScreen(new ClickGuiScreen())).dimensions(6, 6, 56, 20).build());
            }
        });
        LOGGER.info("AimX CLIENT loaded with {} modules", modules.all.size());
    }
}
