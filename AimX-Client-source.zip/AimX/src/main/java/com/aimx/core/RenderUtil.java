package com.aimx.core;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

public final class RenderUtil {
    private static BufferBuilder bb;
    private static Matrix4f mat;
    private static int count;

    // ---------- 3D (one batched draw call per ESP module) ----------
    public static void begin(Matrix4f m, float width) {
        mat = m; count = 0;
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(width);
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
    }

    public static void line(double x1, double y1, double z1, double x2, double y2, double z2, int rgb, float a) {
        float r = (rgb >> 16 & 255) / 255f, g = (rgb >> 8 & 255) / 255f, b = (rgb & 255) / 255f;
        bb.vertex(mat, (float) x1, (float) y1, (float) z1).color(r, g, b, a).next();
        bb.vertex(mat, (float) x2, (float) y2, (float) z2).color(r, g, b, a).next();
        count += 2;
    }

    public static void box(Box b, int rgb, float a) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        line(x1, y1, z1, x2, y1, z1, rgb, a); line(x2, y1, z1, x2, y1, z2, rgb, a);
        line(x2, y1, z2, x1, y1, z2, rgb, a); line(x1, y1, z2, x1, y1, z1, rgb, a);
        line(x1, y2, z1, x2, y2, z1, rgb, a); line(x2, y2, z1, x2, y2, z2, rgb, a);
        line(x2, y2, z2, x1, y2, z2, rgb, a); line(x1, y2, z2, x1, y2, z1, rgb, a);
        line(x1, y1, z1, x1, y2, z1, rgb, a); line(x2, y1, z1, x2, y2, z1, rgb, a);
        line(x2, y1, z2, x2, y2, z2, rgb, a); line(x1, y1, z2, x1, y2, z2, rgb, a);
    }

    public static void end() {
        BufferBuilder.BuiltBuffer built = bb.end();
        if (count > 0) BufferRenderer.drawWithGlobalProgram(built); else built.release();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1f);
    }

    /** Camera-facing text that stays visible through walls. Coordinates are camera-relative. */
    public static void label(MatrixStack ms, Camera cam, double x, double y, double z, String text, float scale) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        ms.push();
        ms.translate(x, y, z);
        ms.multiply(cam.getRotation());
        ms.scale(-scale, -scale, scale);
        VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();
        tr.draw(text, -tr.getWidth(text) / 2f, 0, 0xFFFFFFFF, false, ms.peek().getPositionMatrix(), imm,
                TextRenderer.TextLayerType.SEE_THROUGH, 0x66000000, 0xF000F0);
        imm.draw();
        ms.pop();
    }

    // ---------- 2D helpers ----------
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, color); return; }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int ins = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + ins, y + i, x + w - ins, y + i + 1, color);
            c.fill(x + ins, y + h - i - 1, x + w - ins, y + h - i, color);
        }
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = a >> s & 255, cb = b >> s & 255;
            r |= ((int) (ca + (cb - ca) * t) & 255) << s;
        }
        return r;
    }
}
