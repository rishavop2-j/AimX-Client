package com.aimx.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Shared target selection used by Aim Assist and Target Tracking. */
public final class Targets {
    public static final String[] MODES = {"Closest", "Lowest Health", "Closest To Crosshair"};

    public static LivingEntity find(MinecraftClient mc, double range, double fov, int mode,
                                    boolean players, boolean hostile, boolean passive, boolean walls) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return null;
        float td = mc.getTickDelta();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator() || le instanceof ArmorStandEntity) continue;
            boolean ok = le instanceof PlayerEntity ? players : le instanceof Monster ? hostile : passive;
            if (!ok) continue;
            double d = p.distanceTo(le);
            if (d > range) continue;
            if (!walls && !p.canSee(le)) continue;
            double ang = angle(p, le.getLerpedPos(td).add(0, le.getHeight() * 0.65, 0), td);
            if (ang > fov / 2.0) continue;
            double score = mode == 1 ? le.getHealth() + d * 0.001 : mode == 2 ? ang : d;
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }

    public static float[] rotationTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[]{(float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float) -Math.toDegrees(Math.atan2(dy, h))};
    }

    public static double angle(ClientPlayerEntity p, Vec3d aim, float td) {
        float[] r = rotationTo(p.getCameraPosVec(td), aim);
        float dy = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dp = r[1] - p.getPitch();
        return Math.sqrt(dy * dy + dp * dp);
    }
}
