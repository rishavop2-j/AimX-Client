package com.aimx.core;

import com.aimx.AimXClient;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

/** Persistent JSON settings: .minecraft/config/aimx.json */
public final class ConfigManager {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("aimx.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static boolean save(ModuleManager mm) {
        try {
            JsonObject mods = new JsonObject();
            for (Module m : mm.all) {
                JsonObject o = new JsonObject();
                if (!m.isMomentary()) o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.key);
                JsonObject s = new JsonObject();
                for (Setting st : m.settings) s.addProperty(st.name, st.value);
                o.add("settings", s);
                mods.add(m.name, o);
            }
            JsonObject root = new JsonObject();
            root.addProperty("version", 1);
            root.add("modules", mods);
            Files.createDirectories(FILE.getParent());
            Path tmp = FILE.resolveSibling("aimx.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (Throwable t) {
            AimXClient.LOGGER.error("[AimX] Could not save config", t);
            return false;
        }
    }

    public static boolean load(ModuleManager mm) {
        if (!Files.exists(FILE)) return false;
        try {
            JsonObject mods = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject().getAsJsonObject("modules");
            if (mods == null) return false;
            for (Module m : mm.all) {
                try {
                    if (!mods.has(m.name)) continue;
                    JsonObject o = mods.getAsJsonObject(m.name);
                    if (o.has("key")) m.key = o.get("key").getAsInt();
                    if (o.has("settings")) {
                        JsonObject s = o.getAsJsonObject("settings");
                        for (Setting st : m.settings) if (s.has(st.name)) st.set(s.get(st.name).getAsDouble());
                    }
                    if (!m.isMomentary() && o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
                } catch (Throwable t) {
                    AimXClient.LOGGER.warn("[AimX] Bad config entry for {}, skipped", m.name);
                }
            }
            return true;
        } catch (Throwable t) {
            AimXClient.LOGGER.error("[AimX] Config unreadable, keeping a backup and using defaults", t);
            try { Files.move(FILE, FILE.resolveSibling("aimx.json.bak"), StandardCopyOption.REPLACE_EXISTING); } catch (Throwable ignored) {}
            return false;
        }
    }
}
