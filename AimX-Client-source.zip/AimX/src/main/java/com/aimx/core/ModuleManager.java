package com.aimx.core;

import com.aimx.AimXClient;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import java.util.*;
import java.util.function.Consumer;

public class ModuleManager {
    public final List<Module> all = new ArrayList<>();
    private final Map<Module, Boolean> keyDown = new HashMap<>();
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private long lastFrame = System.nanoTime();

    public void register(Module m) { all.add(m); }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> c) {
        for (Module m : all) if (m.getClass() == c) return (T) m;
        return null;
    }

    private boolean ready() { return mc.player != null && mc.world != null; }

    private void each(Consumer<Module> c) {
        for (Module m : all) {
            if (!m.isEnabled()) continue;
            try { c.accept(m); } catch (Throwable t) { m.fail(t); }
        }
    }

    public void preTick() { if (ready()) each(m -> m.onPreTick(mc.player)); }
    public void tick() { if (ready()) each(m -> m.onTick(mc.player)); }

    public void frame() {
        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - lastFrame) / 1e9f);
        lastFrame = n;
        if (ready()) each(m -> m.onFrame(mc.player, dt));
    }

    public void render3d(WorldRenderContext ctx) { if (ready()) each(m -> m.onRender3d(ctx)); }
    public void hud(DrawContext ctx, float td) { if (ready()) each(m -> m.onHud(ctx, td)); }

    /** Keybind polling (edge triggered). Ignored while any screen is open. */
    public void pollKeys() {
        long h = mc.getWindow().getHandle();
        for (Module m : all) {
            if (m.key < 0) { keyDown.put(m, false); continue; }
            boolean d;
            try { d = InputUtil.isKeyPressed(h, m.key); } catch (Throwable t) { d = false; }
            boolean was = keyDown.getOrDefault(m, false);
            keyDown.put(m, d);
            if (d && !was && mc.currentScreen == null) {
                try { m.toggle(); } catch (Throwable t) { AimXClient.LOGGER.error("[AimX] key toggle failed", t); }
            }
        }
    }

    public void resetAll() {
        for (Module m : all) {
            m.setEnabled(false);
            for (Setting s : m.settings) s.reset();
            m.key = m.defaultKeyCode();
            if (m.defEnabled) m.setEnabled(true);
        }
    }

    public void disableAll() { for (Module m : all) m.setEnabled(false); }
}
