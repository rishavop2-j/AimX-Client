package com.aimx.core;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"), VISUALS("Visuals"), SETTINGS("Settings");
    public final String label;
    Category(String label) { this.label = label; }
}
