package com.aimx.core;

import com.aimx.AimXClient;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/** Base class for every feature. Hooks are only called while the module is enabled. */
public abstract class Module {
    public final String name, description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    public int key = -1;
    public boolean defEnabled = false;
    protected int defKey = -1;
    /** Momentary modules run a one-shot action when switched on and never stay on. */
    protected boolean momentary = false;
    private boolean enabled;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Setting add(Setting s) { settings.add(s); return s; }
    protected void defaultKey(int k) { key = k; defKey = k; }
    public int defaultKeyCode() { return defKey; }

    public boolean isEnabled() { return enabled; }
    public boolean isMomentary() { return momentary; }

    public void setEnabled(boolean on) {
        if (momentary) { if (on) run(this::onEnable); return; }
        if (on == enabled) return;
        enabled = on;
        boolean ok = run(on ? this::onEnable : this::onDisable);
        if (!ok && on) enabled = false;
    }

    public void toggle() { setEnabled(!enabled); }

    /** Called by the manager when a hook throws: switch off safely so the game keeps running. */
    public void fail(Throwable t) {
        AimXClient.LOGGER.error("[AimX] Module '{}' crashed and was disabled", name, t);
        enabled = false;
        run(this::onDisable);
    }

    private boolean run(Runnable r) {
        try { r.run(); return true; }
        catch (Throwable t) { AimXClient.LOGGER.error("[AimX] Module '{}' error", name, t); return false; }
    }

    protected void info(String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("\u00a75[AimX] \u00a7f" + msg), true);
    }

    /** The integrated-server copy of the player. Only exists in singleplayer worlds. */
    protected ServerPlayerEntity serverPlayer() {
        IntegratedServer s = mc.getServer();
        if (s == null || mc.player == null) return null;
        return s.getPlayerManager().getPlayer(mc.player.getUuid());
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onPreTick(ClientPlayerEntity p) {}
    public void onTick(ClientPlayerEntity p) {}
    public void onFrame(ClientPlayerEntity p, float dt) {}
    public void onRender3d(WorldRenderContext ctx) {}
    public void onHud(DrawContext ctx, float tickDelta) {}
}
