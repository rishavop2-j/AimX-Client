package com.aimx.core;

import net.minecraft.util.math.MathHelper;
import java.util.Locale;

/** One configurable value: switch, slider, option cycler or hue slider. */
public class Setting {
    public enum Type { BOOL, NUM, ENUM, HUE }

    public final String name;
    public final Type type;
    public final double min, max, step, def;
    public final String[] options;
    public double value;

    private Setting(String name, Type type, double def, double min, double max, double step, String[] options) {
        this.name = name; this.type = type; this.def = def; this.min = min; this.max = max;
        this.step = step; this.options = options; this.value = def;
    }

    public static Setting bool(String n, boolean d) { return new Setting(n, Type.BOOL, d ? 1 : 0, 0, 1, 1, null); }
    public static Setting num(String n, double d, double min, double max, double step) { return new Setting(n, Type.NUM, d, min, max, step, null); }
    public static Setting mode(String n, int d, String... o) { return new Setting(n, Type.ENUM, d, 0, o.length - 1, 1, o); }
    public static Setting hue(String n, double d) { return new Setting(n, Type.HUE, d, 0, 360, 1, null); }

    public boolean on() { return value >= 0.5; }
    public double num() { return value; }
    public float f() { return (float) value; }
    public int idx() { return (int) Math.round(value); }
    public String option() { return options[idx()]; }
    public int rgb() { return MathHelper.hsvToRgb((float) (value / 360.0), 0.7f, 1f); }

    public void set(double v) {
        if (Double.isNaN(v)) return;
        switch (type) {
            case BOOL -> value = v >= 0.5 ? 1 : 0;
            case ENUM -> value = MathHelper.clamp((int) Math.round(v), 0, options.length - 1);
            default -> {
                double s = step > 0 ? Math.round((v - min) / step) * step + min : v;
                value = Math.max(min, Math.min(max, s));
            }
        }
    }

    public void cycle() {
        if (type == Type.BOOL) set(on() ? 0 : 1);
        else if (type == Type.ENUM) set((idx() + 1) % options.length);
    }

    public void reset() { value = def; }

    public String display() {
        return switch (type) {
            case BOOL -> on() ? "ON" : "OFF";
            case ENUM -> option();
            default -> step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
        };
    }
}
